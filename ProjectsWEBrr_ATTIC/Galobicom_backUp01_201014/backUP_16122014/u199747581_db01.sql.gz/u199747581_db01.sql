-- MySQL dump 10.13  Distrib 5.1.69, for redhat-linux-gnu (x86_64)
--
-- Host: localhost    Database: u199747581_db01
-- ------------------------------------------------------
-- Server version	5.1.69

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `blog`
--

DROP TABLE IF EXISTS `blog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `blog` (
  `id_blog` int(4) NOT NULL AUTO_INCREMENT,
  `idfk_user` int(3) NOT NULL,
  `titulo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `contenido` text COLLATE utf8_unicode_ci NOT NULL,
  `img_link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ext_link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `categoria` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `fec_publicado` datetime NOT NULL,
  PRIMARY KEY (`id_blog`),
  KEY `idfk_user` (`idfk_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de noticias de la seccion realGalobo ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog`
--

/*!40000 ALTER TABLE `blog` DISABLE KEYS */;
/*!40000 ALTER TABLE `blog` ENABLE KEYS */;

--
-- Table structure for table `equipos`
--

DROP TABLE IF EXISTS `equipos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `equipos` (
  `id_equipo` int(2) NOT NULL AUTO_INCREMENT,
  `nom_equipo` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `puntos` int(2) NOT NULL,
  `jugados` int(2) NOT NULL,
  `ganados` int(2) NOT NULL,
  `empatados` int(2) NOT NULL,
  `perdidos` int(2) NOT NULL,
  `gol_favor` int(3) NOT NULL,
  `gol_contra` int(3) NOT NULL,
  PRIMARY KEY (`id_equipo`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla equipos liga boadilla futbol7';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `equipos`
--

/*!40000 ALTER TABLE `equipos` DISABLE KEYS */;
INSERT INTO `equipos` VALUES (1,'Real Galobo C.F',5,6,1,2,3,16,28),(2,'A.E. Briones',12,5,4,0,1,18,13),(3,'Zenit Cientos F.C.',10,6,3,1,2,22,15),(4,'Los de Siempre',8,5,2,2,1,13,11),(5,'All Blacks',6,6,2,0,4,17,17),(6,'Celtic de Maca F.C.',8,6,2,2,2,19,20),(7,'Las Lomas U.D.',6,5,2,0,3,14,20),(8,'Monalissa',1,6,0,1,5,10,16),(9,'Real Ciudadela',9,6,3,0,3,16,20),(10,'El Reencuentro',15,5,5,0,0,37,12);
/*!40000 ALTER TABLE `equipos` ENABLE KEYS */;

--
-- Table structure for table `jugadores_goles`
--

DROP TABLE IF EXISTS `jugadores_goles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jugadores_goles` (
  `idfk_jugador` int(2) NOT NULL,
  `idfk_resultado` int(2) NOT NULL,
  `goles` int(11) NOT NULL,
  PRIMARY KEY (`idfk_jugador`,`idfk_resultado`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de goles de jugador en partido, ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugadores_goles`
--

/*!40000 ALTER TABLE `jugadores_goles` DISABLE KEYS */;
INSERT INTO `jugadores_goles` VALUES (9,5,2),(11,5,2),(9,9,2),(10,9,1),(9,15,1),(4,15,1),(9,17,1),(16,17,1),(16,24,1),(9,24,1),(9,27,2),(8,27,1);
/*!40000 ALTER TABLE `jugadores_goles` ENABLE KEYS */;

--
-- Table structure for table `jugadoresga`
--

DROP TABLE IF EXISTS `jugadoresga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `jugadoresga` (
  `id_jugador` int(2) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(15) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `nom_camiseta` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `posicion` char(3) COLLATE utf8_unicode_ci NOT NULL,
  `Comentario` varchar(500) COLLATE utf8_unicode_ci NOT NULL,
  `cod_magico` varchar(25) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_jugador`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de perfiles de jugadores';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jugadoresga`
--

/*!40000 ALTER TABLE `jugadoresga` DISABLE KEYS */;
INSERT INTO `jugadoresga` VALUES (1,'Jose','\"Parra\"','PARRA','POT','Teo Sellers no es tonteria.Lo parra todo!',''),(4,'Mario','\"Romario\"','MARIO','DEF','defensa',''),(5,'Alberto','Foruny','FORU','DEF','Muy versátil, se adapta cual búho a una noche de caza, gran rematador y si sube...SUBE!',''),(7,'Gonzalo','Hernandez','GON','CNT','Medio Centro',''),(8,'David','\"Nazario DaLima\"','DEIVID N.','DEL','Delantero centro muy pesado',''),(9,'Hugo','Cañibano','HUGO','DEL','Jugador muy gorila, peleón, con potencia máxima de disparo.',''),(10,'Curro','\"Jimenez\"','KURRO','DEF','Defensa',''),(11,'Pablo','\"Pableras\"','KOKO','CNT','Lateral',''),(13,'Antonio','Tolbaños','TOÑIN','DEF','Jugador Estorbo',''),(14,'Angel','Yagüe','YAGÚE C.','CNT','centro campista',''),(16,'Adrian','\"Pietrolini\"','PIETRO','CNT','Medio Centro Adelantado',''),(20,'Sergio','\"Serch\"','SERCH','CNT','Lateral','');
/*!40000 ALTER TABLE `jugadoresga` ENABLE KEYS */;

--
-- Table structure for table `mensajesblog`
--

DROP TABLE IF EXISTS `mensajesblog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajesblog` (
  `id_mensaje` int(5) NOT NULL AUTO_INCREMENT,
  `idfk_blog` int(4) NOT NULL,
  `idfk_user` int(3) NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  `fec_publicado` datetime NOT NULL,
  PRIMARY KEY (`id_mensaje`),
  KEY `idfk_noticia` (`idfk_blog`),
  KEY `idfk_user` (`idfk_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla mensajes para noticias en realGalobo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajesblog`
--

/*!40000 ALTER TABLE `mensajesblog` DISABLE KEYS */;
/*!40000 ALTER TABLE `mensajesblog` ENABLE KEYS */;

--
-- Table structure for table `mensajesga`
--

DROP TABLE IF EXISTS `mensajesga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `mensajesga` (
  `id_mensaje` int(5) NOT NULL AUTO_INCREMENT,
  `idfk_noticia` int(4) NOT NULL,
  `idfk_user` int(3) NOT NULL,
  `mensaje` text COLLATE utf8_unicode_ci NOT NULL,
  `fec_publicado` datetime NOT NULL,
  PRIMARY KEY (`id_mensaje`),
  KEY `idfk_noticia` (`idfk_noticia`),
  KEY `idfk_user` (`idfk_user`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla mensajes para noticias en realGalobo';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `mensajesga`
--

/*!40000 ALTER TABLE `mensajesga` DISABLE KEYS */;
INSERT INTO `mensajesga` VALUES (1,2,1,'El Real Galobo deja escapar 2 puntos en su cita con el derbi; cualquiera de los 2 equipos pudo ganar','2014-11-13 16:35:20');
/*!40000 ALTER TABLE `mensajesga` ENABLE KEYS */;

--
-- Table structure for table `noticiasga`
--

DROP TABLE IF EXISTS `noticiasga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `noticiasga` (
  `id_noticia` int(4) NOT NULL AUTO_INCREMENT,
  `idfk_user` int(3) NOT NULL,
  `titulo` varchar(90) COLLATE utf8_unicode_ci NOT NULL,
  `contenido` text COLLATE utf8_unicode_ci NOT NULL,
  `img_link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `ext_link` varchar(250) COLLATE utf8_unicode_ci NOT NULL,
  `fec_publicado` datetime NOT NULL,
  PRIMARY KEY (`id_noticia`),
  KEY `idfk_user` (`idfk_user`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de noticias de la seccion realGalobo ';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `noticiasga`
--

/*!40000 ALTER TABLE `noticiasga` DISABLE KEYS */;
INSERT INTO `noticiasga` VALUES (1,1,'Inicio de la Liga Municipal de Boadilla, categoría Senior 1ª (2014-2015)','El Real Galobo C.F. comienza la liga con novedades en la plantilla, cambio de equipación y nuevo guardameta, datos importantes para esta campaña, que sin una pretemporada planificada y mucho menos materializada, pinta, por lo que se comenta en el graderío, a fracaso monumental, debido creo yo, a bajas importantes y fichajes fallidos de última hora; con todo esto y poco más que comentar deciros, que aquí se informará de todo lo que vaya sucediendo durante el transcurso de la competición, y demás cositas reseñables de la misma, gracias a los jugadores y a la afición que son y somos muy sabios...ánimo y a por todas. \"Real Galobo Ale Aleee Real Galobo alee alee y Real Galobo ALE\"...','imgruvio/escudo-real-galobo_modificado2.gif','','2014-10-16 00:57:19'),(2,1,'El Derbi.','En unas horas tendrá lugar el primer tu a tu, entre dos equipos rivales que se conocen a la perfección; para este partido nuestro equipo ha preparado a conciencia una estrategia nueva e innovadora en el fútbol 7. No os lo perdáis, puede que nos sorprendan con una catapulta infernal, finalizada con una \"chilenieskaa\"!!..Real GAlobo ALe!','http://3.bp.blogspot.com/_O78uuGpNAIg/SCC8_Gg4XyI/AAAAAAAAAYs/A0V0BZF-zvU/s1600/115982478_513090fe45_o%5B1%5D.jpg','','2014-11-09 00:10:20');
/*!40000 ALTER TABLE `noticiasga` ENABLE KEYS */;

--
-- Table structure for table `puntos_quiniela`
--

DROP TABLE IF EXISTS `puntos_quiniela`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `puntos_quiniela` (
  `id_puntosQuini` int(2) NOT NULL AUTO_INCREMENT,
  `idfk_user` int(2) NOT NULL,
  `puntosQuini` int(4) NOT NULL,
  `efect_quiniela` double NOT NULL,
  `efect_goleadores` double NOT NULL,
  `efect_total` double NOT NULL,
  PRIMARY KEY (`id_puntosQuini`),
  UNIQUE KEY `id_puntosQuini` (`id_puntosQuini`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de Puntos de usuario por hacer la quiniela';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `puntos_quiniela`
--

/*!40000 ALTER TABLE `puntos_quiniela` DISABLE KEYS */;
INSERT INTO `puntos_quiniela` VALUES (1,3,120,0,0,0),(2,4,120,0,0,0),(3,1,195,0,0,0),(4,8,70,0,0,0),(5,9,50,0,0,0),(6,10,255,0,0,0),(7,12,40,0,0,0),(8,11,98,0,0,0),(9,13,20,0,0,0),(10,16,80,0,0,0),(11,5,35,0,0,0);
/*!40000 ALTER TABLE `puntos_quiniela` ENABLE KEYS */;

--
-- Table structure for table `quinielaga`
--

DROP TABLE IF EXISTS `quinielaga`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `quinielaga` (
  `id_quinielaga` int(4) NOT NULL AUTO_INCREMENT,
  `idfk_user` int(2) NOT NULL,
  `idfk_resultado` int(3) NOT NULL,
  `jornada` int(2) NOT NULL,
  `ids_goleadores` varchar(8) COLLATE utf8_unicode_ci NOT NULL,
  `quiniela_user` varchar(1) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_quinielaga`)
) ENGINE=MyISAM AUTO_INCREMENT=171 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla de quinielas hechas por usuario y partidos de la jorna';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `quinielaga`
--

/*!40000 ALTER TABLE `quinielaga` DISABLE KEYS */;
INSERT INTO `quinielaga` VALUES (1,3,1,1,'','2'),(2,3,2,1,'','1'),(3,3,3,1,'','2'),(4,3,4,1,'','1'),(5,3,5,1,'9,14,11','2'),(6,4,1,1,'','2'),(7,4,2,1,'','x'),(8,4,3,1,'','2'),(9,4,4,1,'','2'),(10,4,5,1,'8,9,11','2'),(11,1,1,1,'','2'),(12,1,2,1,'','1'),(13,1,3,1,'','2'),(14,1,4,1,'','1'),(15,1,5,1,'9,9,8','2'),(16,8,1,1,'','x'),(17,8,2,1,'','1'),(18,8,3,1,'','1'),(19,8,4,1,'','2'),(20,8,5,1,'9,16,11','2'),(21,9,1,1,'','2'),(22,9,2,1,'','2'),(23,9,3,1,'','1'),(24,9,4,1,'','1'),(25,9,5,1,'9,16,11','2'),(26,10,1,1,'','1'),(27,10,2,1,'','1'),(28,10,3,1,'','2'),(29,10,4,1,'','2'),(30,10,5,1,'9,9,16','x'),(36,12,1,1,'','1'),(37,12,2,1,'','1'),(38,12,3,1,'','2'),(39,12,4,1,'','1'),(40,12,5,1,'9,14,16','2'),(41,11,1,1,'','1'),(42,11,2,1,'','1'),(43,11,3,1,'','1'),(44,11,4,1,'','2'),(45,11,5,1,'9,16,9','2'),(46,10,6,2,'','2'),(47,10,7,2,'','2'),(48,10,8,2,'','1'),(49,10,9,2,'9,9,8','2'),(50,10,10,2,'','1'),(51,1,6,2,'','1'),(52,1,7,2,'','2'),(53,1,8,2,'','1'),(54,1,9,2,'9,8,11','2'),(55,1,10,2,'','1'),(56,11,6,2,'','1'),(57,11,7,2,'','x'),(58,11,8,2,'','1'),(59,11,9,2,'9,10,9','2'),(60,11,10,2,'','1'),(61,4,6,2,'','x'),(62,4,7,2,'','x'),(63,4,8,2,'','x'),(64,4,9,2,'9,14,20','x'),(65,4,10,2,'','x'),(66,12,6,2,'','2'),(67,12,7,2,'','1'),(68,12,8,2,'','x'),(69,12,9,2,'9,11,20','2'),(70,12,10,2,'','x'),(71,13,6,2,'','1'),(72,13,7,2,'','2'),(73,13,8,2,'','2'),(74,13,9,2,'9,8,16','2'),(75,13,10,2,'','x'),(76,8,6,2,'','2'),(77,8,7,2,'','1'),(78,8,8,2,'','x'),(79,8,9,2,'9,20,8','2'),(80,8,10,2,'','2'),(81,4,11,3,'','x'),(82,4,12,3,'','1'),(83,4,13,3,'','x'),(84,4,14,3,'','2'),(85,4,15,3,'11,14,8','1'),(86,10,11,3,'','1'),(87,10,12,3,'','1'),(88,10,13,3,'','2'),(89,10,14,3,'','1'),(90,10,15,3,'9,9,16','1'),(91,3,11,3,'','1'),(92,3,12,3,'','2'),(93,3,13,3,'','2'),(94,3,14,3,'','1'),(95,3,15,3,'9,10,14','1'),(96,1,11,3,'','x'),(97,1,12,3,'','1'),(98,1,13,3,'','1'),(99,1,14,3,'','2'),(100,1,15,3,'9,8,10','1'),(31,3,11,2,'','2'),(32,3,12,2,'','x'),(33,3,13,2,'','1'),(34,3,14,2,'','2'),(35,3,15,2,'9,11,14','x'),(101,16,11,3,'','2'),(102,16,12,3,'','2'),(103,16,13,3,'','2'),(104,16,14,3,'','1'),(105,16,15,3,'9,10,16','2'),(106,10,16,4,'','1'),(107,10,17,4,'9,9,11','2'),(108,10,18,4,'','2'),(109,10,19,4,'','1'),(110,10,20,4,'','1'),(111,4,16,4,'','1'),(112,4,17,4,'4,8,13','2'),(113,4,18,4,'','1'),(114,4,19,4,'','2'),(115,4,20,4,'','1'),(116,1,16,4,'','1'),(117,1,17,4,'9,10,11','2'),(118,1,18,4,'','1'),(119,1,19,4,'','x'),(120,1,20,4,'','2'),(121,16,16,4,'','1'),(122,16,17,4,'9,9,11','1'),(123,16,18,4,'','1'),(124,16,19,4,'','1'),(125,16,20,4,'','x'),(140,16,25,5,'','1'),(139,16,24,5,'9,5,10','2'),(138,16,23,5,'','2'),(137,16,22,5,'','1'),(136,16,21,5,'','1'),(131,5,16,4,'','x'),(132,5,17,4,'9,11,13','2'),(133,5,18,4,'','1'),(134,5,19,4,'','x'),(135,5,20,4,'','2'),(141,10,21,5,'','x'),(142,10,22,5,'','2'),(143,10,23,5,'','2'),(144,10,24,5,'9,9,11','2'),(145,10,25,5,'','2'),(146,1,21,5,'','1'),(147,1,22,5,'','2'),(148,1,23,5,'','2'),(149,1,24,5,'9,10,11','x'),(150,1,25,5,'','1'),(151,4,21,5,'','x'),(152,4,22,5,'','1'),(153,4,23,5,'','2'),(154,4,24,5,'10,8,13','x'),(155,4,25,5,'','1'),(156,1,26,6,'','1'),(157,1,27,6,'9,9,10','x'),(158,1,28,6,'','2'),(159,1,29,6,'','1'),(160,1,30,6,'','2'),(161,10,26,6,'','1'),(162,10,27,6,'9,9,8','1'),(163,10,28,6,'','1'),(164,10,29,6,'','1'),(165,10,30,6,'','2'),(166,1,31,7,'','x'),(167,1,32,7,'','2'),(168,1,33,7,'9,9,8','1'),(169,1,34,7,'','2'),(170,1,35,7,'','2');
/*!40000 ALTER TABLE `quinielaga` ENABLE KEYS */;

--
-- Table structure for table `resultados`
--

DROP TABLE IF EXISTS `resultados`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `resultados` (
  `id_resultado` int(3) NOT NULL AUTO_INCREMENT COMMENT 'el id de cada resultado,por cada jornada se generaran tantos id como partidos haya.',
  `idfk_equipoA` int(2) NOT NULL,
  `idfk_equipoB` int(2) NOT NULL,
  `gol_A` int(2) DEFAULT NULL,
  `gol_B` int(2) DEFAULT NULL,
  `jornada` int(2) DEFAULT NULL,
  `fec_hora` datetime DEFAULT NULL,
  `campo` int(1) NOT NULL COMMENT '=1, cd fútbol 7. =2 , fútbol 7 1-A.',
  `quiniela` varchar(1) COLLATE utf8_unicode_ci DEFAULT NULL,
  `activa` int(1) NOT NULL COMMENT 'Para activar ="1" o desactivar= "2", la quiniela a los usuarios q no la hayan hecho antes del sabado por la mañana.cuando decida el admin anular a traves de la aplica.',
  PRIMARY KEY (`id_resultado`)
) ENGINE=MyISAM AUTO_INCREMENT=36 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='tabla resultados,jornada y quiniela.';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `resultados`
--

/*!40000 ALTER TABLE `resultados` DISABLE KEYS */;
INSERT INTO `resultados` VALUES (1,2,3,3,1,1,'2014-10-18 17:00:00',1,'1',2),(2,7,10,2,9,1,'2014-10-18 18:00:00',1,'2',2),(3,5,8,7,1,1,'2014-10-19 16:00:00',2,'1',2),(4,9,4,0,3,1,'2014-10-19 17:00:00',2,'2',2),(5,6,1,4,4,1,'2014-10-19 16:00:00',1,'x',2),(6,4,6,3,4,2,'2014-10-25 17:00:00',1,'2',2),(7,8,9,2,6,2,'2014-10-26 16:00:00',2,'2',2),(8,10,5,3,2,2,'2014-10-26 17:00:00',2,'1',2),(9,3,1,4,3,2,'2014-10-26 19:00:00',2,'1',2),(10,2,7,NULL,NULL,2,NULL,2,NULL,2),(11,7,3,5,4,3,'2014-11-08 18:00:00',1,'1',2),(12,6,8,1,1,3,'2014-11-08 17:00:00',1,'x',2),(13,5,2,5,2,3,'2014-11-09 16:00:00',2,'1',2),(14,9,10,2,8,3,'2014-11-08 17:00:00',2,'2',2),(15,1,4,2,2,3,'2014-11-09 19:00:00',2,'x',2),(16,2,9,3,2,4,'2014-11-15 20:00:00',2,'1',2),(17,8,1,0,2,4,'2014-11-16 19:00:00',2,'2',2),(18,10,6,5,4,4,'2014-11-16 16:00:00',2,'1',2),(19,3,4,1,1,4,'2014-11-16 17:00:00',2,'x',2),(20,7,5,2,0,4,'2014-11-15 18:00:00',1,'1',2),(21,4,8,4,2,5,'2014-11-22 19:00:00',1,'1',2),(22,9,7,3,2,5,'2014-11-22 18:00:00',1,'1',2),(23,6,2,2,3,5,'2014-11-23 16:00:00',2,'2',2),(24,1,10,2,12,5,'2014-11-23 17:00:00',2,'2',2),(25,5,3,1,6,5,'2014-11-23 19:00:00',2,'2',2),(26,10,4,NULL,NULL,6,NULL,1,NULL,2),(27,2,1,7,3,6,'2014-11-29 17:00:00',1,'1',2),(28,7,6,3,4,6,'2014-11-30 16:00:00',2,'2',2),(29,3,8,6,4,6,'2014-11-30 17:00:00',2,'1',2),(30,5,9,2,3,6,'2014-11-30 19:00:00',2,'2',2),(31,6,5,NULL,NULL,7,'2014-12-14 16:00:00',2,NULL,2),(32,9,3,NULL,NULL,7,'2014-12-13 18:00:00',1,NULL,2),(33,1,7,NULL,NULL,7,'2014-12-13 17:00:00',2,NULL,2),(34,8,10,NULL,NULL,7,'2014-12-14 19:00:00',2,NULL,2),(35,4,2,NULL,NULL,7,'2014-12-14 17:00:00',2,NULL,2);
/*!40000 ALTER TABLE `resultados` ENABLE KEYS */;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id_user` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `nick` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `fec_alta` date NOT NULL,
  `fec_baja` date DEFAULT NULL,
  `nivel_acceso` int(2) NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla usuarios principal';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'Rubén','García Álvarez','Ruvito_O','raibandj@hotmail.com','77f71f3aedf57876448a141b5eda12ebb481d527','2014-09-04',NULL,1),(2,'Prueba Uno','User Nivel Básico','Prueba_rr01','rubenruvito@gmail.com','568aad8c7d0d1bcc84b8e9f6689ffb98dec9095c','2014-10-16',NULL,5),(3,'Angel','Yague','Enllelo','angelyawe@gmail.com','9736786bd6600d63fff5829f86aad3a2c5d8e311','2014-10-16',NULL,5),(4,'Emilio','García Fuentes','Emilín_60','emiliogarfu@hotmail.com','e2b6637df486318762f6638ec80d4823e3897336','2014-10-16',NULL,5),(5,'Daniel','Pintado','Tesla','daniwarner69@gmail.com','18bc67ac2845d32e72bfc0bc9b6cc7d72c1d2e10','2014-10-16',NULL,5),(6,'Toti','Toti','Toti','tottiherr@gmail.com','56b45a22410ed3c06518c24438c214fadfb0bb43','2014-10-16',NULL,5),(7,'Angela','Marinovic','Enyela','marinovic_86@hotmail.com','e341a66d89e8073e8489938c6c2b2b1d974b5e79','2014-10-17',NULL,5),(8,'Sergio','Lucia Casanova','Serch','only_serch@hotmail.com','d07d1a5f0085a8b7614f636b0752b1f3083efea0','2014-10-17',NULL,5),(9,'Antonio','Tolbaños Lopez','Tolber','familitolbi@hotmail.com','dd1de8e23a16b2337737169bf494976b208bd614','2014-10-18',NULL,5),(10,'Jose','Curras','Kurro','josecurras12@hotmail.com','ff212a01b59b5e3c7aedd9f3f8b42f8ccb205fdf','2014-10-18',NULL,5),(11,'Hugo','Hugo','Hugo','hugocani@hotmail.com','70352f41061eda4ff3c322094af068ba70c3b38b','2014-10-18',NULL,5),(12,'Enrique','Enrique','Quique','quique808@gmail.com','a15825a29089ef330d8470b38d0027f6351a7468','2014-10-18',NULL,5),(13,'David','López Arias','DeividR9','davidlopezarias9@gmail.com','a82ce147837a36b5d98d474479c2616cd89b3681','2014-10-26',NULL,5),(14,'Alberto','Foruny Olcina','Foru','alforuner@hotmail.com','88b4e7fa5c6f985e994b6a887e3b1d45fd6d85b1','2014-11-03',NULL,5),(15,'Miguel','Saavedra Gómez','chocomoon','saavedra_gomez@hotmail.com','457a98d3817cf88cf46882396697194f4a41fa3b','2014-11-03',NULL,5),(16,'Valentin','Carrasco Cano','retaco','valentin.carrasco.c@gmail.com','215de7f5fc41f5f60a8a64313b0d44b5dba0194d','2014-11-06',NULL,5),(17,'Elena','Bocos','Helen','elenabocos@hotmail.com','28da1e0a087e58ea070a57ea10ad79cc6b75037e','2014-11-06',NULL,5),(18,'Guebar','Guengor','Manu','manuelasenjo88@gmail.com','8abcce9bb86dce1c52ad01b0661fa4b8539721ce','2014-11-09',NULL,5),(19,'Adrian','Adrian','Pietro','ascatleti@hotmail.com','58b2b9b880b6d67a63650a35441a24943336d0a7','2014-12-03',NULL,5);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;

--
-- Table structure for table `users_temp`
--

DROP TABLE IF EXISTS `users_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users_temp` (
  `id_user` int(3) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `apellidos` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `nick` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `email` varchar(120) COLLATE utf8_unicode_ci NOT NULL,
  `password` varchar(80) COLLATE utf8_unicode_ci NOT NULL,
  `cod_activacion` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id_user`)
) ENGINE=MyISAM AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='Tabla usuarios temporal';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users_temp`
--

/*!40000 ALTER TABLE `users_temp` DISABLE KEYS */;
INSERT INTO `users_temp` VALUES (9,'Adrian','Adrian','Pietro','ascatleti@hotmail.com','58b2b9b880b6d67a63650a35441a24943336d0a7','oda6v41580682541T2u9');
/*!40000 ALTER TABLE `users_temp` ENABLE KEYS */;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-12-16 18:28:35
