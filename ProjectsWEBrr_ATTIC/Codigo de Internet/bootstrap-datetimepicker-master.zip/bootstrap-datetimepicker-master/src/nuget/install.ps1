# install.ps1
$DTE.ItemOperations.Navigate("https://github.com/Eonasdan/bootstrap-datetimepicker#change-log", $DTE.vsNavigateOptions.vsNavigateOptionsNewWindow)
